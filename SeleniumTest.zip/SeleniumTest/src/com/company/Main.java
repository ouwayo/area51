package com.company;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class Main {
    @Test public void login() throws InterruptedException {

//    public static void main(String[] args) throws InterruptedException {
	// write your code here
        System.setProperty("webdriver.chrome.driver",
                "C:\\webdrivers\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        //Applied wait time
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //maximize window
        driver.manage().window().maximize();
        driver.get("http://172.16.4.242//ashesibusiness/login_form.php");
        WebElement email = driver.findElementById("email");
        email.sendKeys("oscaruwayo@gmail.com");
       WebElement password = driver.findElement(By.id("password"));//findElementByClassName("whsOnd zHQkBf");
        password.sendKeys("123456789");
       WebElement nextButton =driver.findElementByXPath("//input[@value='Login']");
       nextButton.click();
        String actualUrl="http://172.16.4.242//ashesibusiness/profile.php";
        Thread thread = new Thread();
        thread.sleep(5000);
        String expectedUrl= driver.getCurrentUrl();
        Assert.assertEquals(expectedUrl,actualUrl);
        System.out.println(expectedUrl);
    }
}

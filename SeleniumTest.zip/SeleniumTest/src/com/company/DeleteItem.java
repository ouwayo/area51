package com.company;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;
public class DeleteItem {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver",
                "C:\\webdrivers\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        //Applied wait time
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //maximize window
        driver.manage().window().maximize();
        driver.get("http://172.16.4.242//ashesibusiness/profile.php");
        WebElement addToCart = driver.findElement(By.id("product"));
        addToCart.click();
        WebElement cart = driver.findElement(By.className("dropdown-toggle"));
        String Text1 = cart.getText();
        cart.click();


        WebElement editCart = driver.findElement(By.xpath("//a[@href='cart.php']"));//cart.php
        editCart.click();
        WebElement delete =driver.findElementByCssSelector(".remove:first-child");
        delete.click();
    }
}
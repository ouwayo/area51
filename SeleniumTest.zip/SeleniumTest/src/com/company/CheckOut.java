package com.company;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;
public class CheckOut extends Main {
    public static void main(String[] args) throws InterruptedException {
        // write your code here
        System.setProperty("webdriver.chrome.driver",
                "C:\\webdrivers\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        //Applied wait time
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //maximize window
        driver.manage().window().maximize();
        driver.get("http://172.16.4.242//ashesibusiness/profile.php");
        WebElement addToCart= driver.findElement(By.id("product"));
        addToCart.click();
        WebElement cart =driver.findElement(By.className("dropdown-toggle"));
        cart.click();
        WebElement editCart = driver.findElement(By.xpath("//a[@href='cart.php']"));//cart.php
        editCart.click();
        WebElement readyPay =driver.findElementByXPath("//input[@value='Ready to Checkout']");
        readyPay.click();
        WebElement email = driver.findElementById("email");
        email.sendKeys("oscaruwayo@gmail.com");
        WebElement password = driver.findElement(By.id("password"));//findElementByClassName("whsOnd zHQkBf");
        password.sendKeys("123456789");
        WebElement nextButton =driver.findElementByXPath("//input[@value='Login']");
        nextButton.click();
        WebElement payPal =driver.findElementByXPath("//input[@name='submit']");
        payPal.click();
        String actualUrl="https://www.sandbox.paypal.com/webapps/hermes?token=3VF85812AU1520947&useraction=commit&mfid=1582391634317_d78ba6571d88a";
        Thread thread = new Thread();
        thread.sleep(5000);
        String expectedUrl= driver.getCurrentUrl();
        System.out.println(expectedUrl);
        if(actualUrl.equals(expectedUrl)) {
            System.out.println("Test passed"); }
        else {
            System.out.println("Test failed");
        }




        }

    }


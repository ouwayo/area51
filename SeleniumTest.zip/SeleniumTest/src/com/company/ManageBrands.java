package com.company;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class ManageBrands {
    public static void main(String[] args) throws InterruptedException {
        // write your code here
        System.setProperty("webdriver.chrome.driver",
                "C:\\webdrivers\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        //Applied wait time
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //maximize window
        driver.manage().window().maximize();
        driver.get("http://172.16.4.242/ashesibusiness/admin/index.php");

        //Admin Login
        WebElement email = driver.findElementById("email");
        email.sendKeys("oscaruwayo@gmail.com");
        WebElement password = driver.findElement(By.id("password"));//findElementByClassName("whsOnd zHQkBf");
        password.sendKeys("123456789");
        WebElement nextButton =driver.findElementByXPath("//button[@type='button']");
        nextButton.click();


        //select Brands
        WebElement brand = driver.findElement(By.xpath("//a[@href='brands.php']"));
        brand.click();

//        //Add Brand
//        WebElement  addBrand = driver.findElement(By.xpath("//a[@data-toggle='modal']"));
//        addBrand.click();
//        WebElement brandName =driver.findElement(By.xpath("//input[@name='brand_title']"));
//        brandName.sendKeys("Yokohama");
//        WebElement  brandButton = driver. findElement(By.className("add-brand"));
//        brandButton.click();

        //Delete Brands
        WebElement delete =driver.findElementByCssSelector(".delete-brand:last-child");
        delete.click();

    }
}
